package com.example.logindialog;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import au.com.example.logindialog.DashBoard;
import au.com.example.logindialog.MainActivity;
import au.com.example.util.OktonUtill;

public class SendSmsActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.send_sms);
		this.getActionBar().setDisplayHomeAsUpEnabled(true);
		
		Button sendButton = (Button) findViewById(R.id.buttonSend);
		
		Button backButton = (Button) findViewById(R.id.backButton);
		final EditText etPhone = (EditText) findViewById(R.id.editTextPhoneNo);
		final EditText etMsg = (EditText) findViewById(R.id.editTextSMS);
		
		sendButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String phNumber = etPhone.getText().toString();
				String message = etMsg.getText().toString();
				try {
					SmsManager manager = SmsManager.getDefault();
					manager.sendTextMessage(phNumber, null, message, null, null);
					overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left);
					Toast.makeText(getApplicationContext(), "SMS Sent!", Toast.LENGTH_LONG).show();
				} catch (Exception e) {
					Toast.makeText(getApplicationContext(), "SMS not Sent!", Toast.LENGTH_SHORT).show();
					e.printStackTrace();
				} finally {
					startActivity(new Intent(getApplicationContext(), DashBoard.class));;
				}
			}
		});
		
		backButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(getApplicationContext(), DashBoard.class));
				overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left);
			}
		});
		
		
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) 
		{
		
		case R.id.action_logout:
			new AlertDialog.Builder(this)
		    .setIcon(R.drawable.logout)
		    .setTitle("Logout")
		    .setMessage("Are you sure you want to Logout from the application?")
		    .setPositiveButton("Logout", new DialogInterface.OnClickListener()
		    {
		    @Override
		    public void onClick(DialogInterface dialog, int which) {
		        finish();
		        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
		        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); 
		        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		        startActivity(intent);
		        Toast.makeText(getApplicationContext(), "Logged out successfully!", Toast.LENGTH_SHORT).show();
		    }

		    })
		    .setNegativeButton("No", null)
		    .show();
			return true;
			
		case android.R.id.home:
			OktonUtill.startLaunchActivity(this);
			overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left);
			return true;
		}
		
		return false;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	@Override
	public void onBackPressed() {
		super.onBackPressed();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left);
	}
}