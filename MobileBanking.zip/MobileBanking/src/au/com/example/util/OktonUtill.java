package au.com.example.util;

import android.app.Activity;
import android.content.Intent;
import au.com.example.logindialog.DashBoard;

public class OktonUtill {

	public  static void startLaunchActivity(Activity activity){
		Intent intent = new Intent(activity, DashBoard.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		activity.startActivity(intent);
	}
}