package au.com.example.adapters;


import com.example.logindialog.R;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class CustomListAdapter extends BaseAdapter {
	Activity context;
	int[] imageResource;
	String[] itemText;
	@SuppressWarnings("rawtypes")
	Class[] StartClass;
	private LayoutInflater inflater;
//private Typeface typeface;
	public CustomListAdapter (Activity context,int[] imageResource,String[] itemText,@SuppressWarnings("rawtypes") Class[] StartClass){
		this.context = context;
		this.itemText = itemText;
		this.imageResource = imageResource;
		this.StartClass = StartClass;
		inflater = (LayoutInflater)this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return imageResource.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return itemText[position];
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return imageResource[position];
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		View vi=convertView;
		ViewHolder holder;
		if(convertView==null){
			holder = new ViewHolder();
			vi = inflater.inflate(R.layout.list_adapter_helper, null);
			holder.itemImage = (ImageView) vi.findViewById(R.id.list_item_image);
			vi.setTag(holder);
		}else{
			holder = (ViewHolder) vi.getTag();
		}
		if (holder != null) {
			holder.itemImage.setImageResource(imageResource[position]);
			
		}
		vi.setOnClickListener(new onListItemClick(StartClass[position], context));
		return vi;
	}
	private class ViewHolder{
		ImageView itemImage;
	}
	private class onListItemClick implements OnClickListener{
		@SuppressWarnings("rawtypes")
		Class cls;
		Activity context;
		@SuppressWarnings("rawtypes")
		public onListItemClick(Class cls,Activity context){
			this.cls = cls;
			this.context = context;
		}

		@Override
		public void onClick(View v) {
			
			Intent intent = new Intent(context, cls);
			context.startActivity(intent);
		}
		
	}

}
