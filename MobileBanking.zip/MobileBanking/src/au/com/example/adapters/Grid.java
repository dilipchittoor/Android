package au.com.example.adapters;

import com.example.logindialog.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class Grid extends BaseAdapter {

	int[] images = {R.drawable.balance,R.drawable.paiement_cheque,R.drawable.offers_all,R.drawable.mailbox_icon,
			R.drawable.enquiry_right,R.drawable.deposits_2};
	
	String[] names = {"Balance","Cheque Status","Offers","Mail Box","Enquiry","Deposits"};
	
	
	
	
	Context context;
	
	public Grid(Context applContext){
		context = applContext;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return images.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		 View myView = convertView;
		 
		 
		
	        if (convertView == null) {  
	            System.out.println("entering iffffff");
	            LayoutInflater li = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	            System.out.println("parsing inflateeeeeeee");
	            myView = li.inflate(R.layout.row_grid, null);
System.out.println("inflatinggggggggggggggg");
	            // Add The Image!!!           
	            ImageView iv = (ImageView)myView.findViewById(R.id.imageView_grid);
				
	            iv.setImageResource(images[position]);
	            

	            // Add The Text!!!
	            TextView tv = (TextView)myView.findViewById(R.id.textView_grid);
				
	            tv.setText(names[position] );
	            
	            


	        }
	        return myView;
	    }
//		
//		ImageView iv;
//	
//		if(convertView != null){
//			iv = (ImageView)convertView;	
//		}
//		else{
//			
//			iv = new ImageView(context);
//			iv.setLayoutParams(new GridView.LayoutParams(80,80));
//			iv.setScaleType(ScaleType.CENTER_CROP);
//			iv.setPadding(4, 4, 4, 4);
//		}
//		iv.setImageResource(images[position]);
//		
//		
//	return iv;
		
		
	

}
