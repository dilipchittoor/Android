package au.com.example.adapters;


import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.BaseAdapter;


public class CustomFontAdapter extends BaseAdapter {
	Activity context_font;
	int[] resource;
	@SuppressWarnings("unused")
	private Typeface typeFace;
	@SuppressWarnings("unused")
	private LayoutInflater inflater_font;
	String[] items;
	
	public CustomFontAdapter(Activity context_font,int[] resource,String[]  values){
		this.context_font =  context_font;
		this.resource = resource;
		this.items = values;
		inflater_font = (LayoutInflater)this.context_font.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		inflater_font = LayoutInflater.from(context_font);
		typeFace=Typeface.createFromAsset(context_font.getAssets(), "fonts/Garogier_unhinted.otf");
	}

	
	@Override
    public View getView(int position, View convertView,ViewGroup parent){
		
		if (convertView == null)
        {
//            convertView = inflater_font.inflate(R.layout.dashboard_layout, null);
        }

        
        return convertView;
    }
	

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

}
