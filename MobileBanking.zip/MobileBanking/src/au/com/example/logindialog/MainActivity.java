package au.com.example.logindialog;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Toast;

import com.example.logindialog.R;

public class MainActivity extends Activity {

	final private static int DIALOG_LOGIN = 1;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
//		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left);
		setContentView(R.layout.activity_main);

		SeekBar sb = (SeekBar) findViewById(R.id.seekBar1);
		sb.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
			
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				seekBar.setProgress(0);
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@SuppressWarnings("deprecation")
			@Override
			public void onProgressChanged(SeekBar arg0, int progress, boolean arg2) {
				if (progress > 25) {
					showDialog(DIALOG_LOGIN);
				}
				
			}
		});
//
//		launch_button.setOnClickListener(new View.OnClickListener() {
//
//			@Override
//			public void onClick(View v) {
//				showDialog(DIALOG_LOGIN);
//			}
//		});
	}

	@Override
	protected Dialog onCreateDialog(int id) {

		AlertDialog dialogDetails = null;

		switch (id) {
		case DIALOG_LOGIN:
			LayoutInflater inflater = LayoutInflater.from(this);
			View dialogview = inflater.inflate(R.layout.dialog_layout, null);

			AlertDialog.Builder dialogbuilder = new AlertDialog.Builder(this);
//			dialogbuilder.setTitle("Login");
			dialogbuilder.setView(dialogview);
			dialogDetails = dialogbuilder.create();

			break;
		}

		return dialogDetails;
	}

	@Override
	protected void onPrepareDialog(int id, Dialog dialog) {

		switch (id) {
		case DIALOG_LOGIN:
			final AlertDialog alertDialog = (AlertDialog) dialog;
			Button loginbutton = (Button) alertDialog
					.findViewById(R.id.btn_login);
			Button cancelbutton = (Button) alertDialog
					.findViewById(R.id.btn_cancel);
			final EditText accNum = (EditText) alertDialog
					.findViewById(R.id.editText1);
			
			
			
			final EditText pwd = (EditText) alertDialog
					.findViewById(R.id.password);
			
			

			loginbutton.setOnClickListener(new View.OnClickListener() {

				@SuppressWarnings("deprecation")
				@Override
				public void onClick(View v) {
					
					System.out.println("entering onClick>>>>>>");
					
					alertDialog.dismiss();
					
					String accNumber = accNum.getText().toString();
					String password = pwd.getText().toString();
					
					if(accNumber.equals("") || password.equals("")){
						showDialog(DIALOG_LOGIN);
						Toast toast = Toast.makeText(MainActivity.this, "Please enter credentials", Toast.LENGTH_LONG);
						toast.show();
					}
					else{
						Intent intent = new Intent(MainActivity.this, DashBoard.class);
						startActivity(intent);
						overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left);
					}
		
				}
			});

			cancelbutton.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					alertDialog.dismiss();
					overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left);
				}
			});
			break;
		}
	}
	
	@Override
	public void onBackPressed() {

		finish();
		android.os.Process.killProcess(android.os.Process.myPid());
		finish();
	}
}