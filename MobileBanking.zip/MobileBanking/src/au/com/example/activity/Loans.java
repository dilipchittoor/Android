package au.com.example.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewStub;
import android.widget.ListView;
import android.widget.Toast;
import au.com.example.adapters.CustomListAdapter;
import au.com.example.logindialog.MainActivity;
import au.com.example.util.OktonUtill;

import com.example.logindialog.R;
import com.example.logindialog.SendSmsActivity;

public class Loans  extends Activity {
	
	private  int[] imagResources = new int[] {R.drawable.bill_payment,R.drawable.credit_card,R.drawable.transaction};
	private String[] itemText = new String[] {"Bill payment","Credit Card details","Transactions"};
	@SuppressWarnings("rawtypes")
	private Class[] startClass = new Class[] {BillPayment.class,CreditCard.class,Transactions.class};
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dashboard_layout);
		
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left);
		
		ViewStub vs = (ViewStub) findViewById(R.id.viewStub_home);
		vs.setLayoutResource(R.layout.loans_fragment);
		vs.inflate();
		
		final ListView listview1 = (ListView) findViewById(R.id.right_side_list);;
		listview1.setAdapter(new CustomListAdapter(this, imagResources, itemText, startClass));

		this.getActionBar().setDisplayHomeAsUpEnabled(true);
	}
	
	public void onClickCallMsg (View v) {
		
		if (v.getId() == R.id.imageButton1) {
			  Intent phoneIntent = new Intent(Intent.ACTION_CALL);
			  phoneIntent.setData(Uri.parse("tel:+91-991-225-7288"));
			  try {
			   startActivity(phoneIntent);
			  } catch (ActivityNotFoundException ex) {
			   Toast.makeText(this, "Call failed, please try again later.", Toast.LENGTH_SHORT).show();
			  }
		}
		
		if (v.getId() == R.id.imageButton2) {
			Intent intent = new Intent(Loans.this, SendSmsActivity.class);
			startActivity(intent);
			overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left);
		}
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) 
		{
		
		case R.id.action_logout:
			new AlertDialog.Builder(this)
		    .setIcon(R.drawable.logout)
		    .setTitle("Logout")
		    .setMessage("Are you sure you want to Logout from the application?")
		    .setPositiveButton("Logout", new DialogInterface.OnClickListener()
		    {
		    @Override
		    public void onClick(DialogInterface dialog, int which) {
		        finish();
		        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
		        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); 
		        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		        startActivity(intent);
		        Toast.makeText(getApplicationContext(), "Logged out successfully!", Toast.LENGTH_SHORT).show();
		    }

		    })
		    .setNegativeButton("No", null)
		    .show();
			return true;
			
		case android.R.id.home:
			OktonUtill.startLaunchActivity(this);
			overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left);
			return true;
		}
		return false;
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
	
		getMenuInflater().inflate(R.menu.main, menu);
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
	public void onBackPressed() {

		super.onBackPressed();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left);
	}
}